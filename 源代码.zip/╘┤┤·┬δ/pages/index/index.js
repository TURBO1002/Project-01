var app = getApp();
// 引入时间模块
var util = require('../../utils/util.js');
Page({
  data: {
    imgUrls: [
      'http://www.suifangde.com/images/banner1-1.jpg',
      'http://www.suifangde.com/images/banner1-2.jpg',
      'http://www.suifangde.com/images/banner1-3.jpg',
      'http://www.suifangde.com/images/banner1-4.jpg'
    ],
    listData: [
      { "code": "01", "name": "同仁堂", "medNum": "20", "docNum": "10", "illNum": "2", "thingNum": "20" },
      { "code": "02", "name": "老百姓", "medNum": "20", "docNum": "10", "illNum": "2", "thingNum": "20" },
      { "code": "03", "name": "国大药房", "medNum": "20", "docNum": "10", "illNum": "2", "thingNum": "20" },
      { "code": "04", "name": "大参林", "medNum": "20", "docNum": "10", "illNum": "2", "thingNum": "20" },
      { "code": "05", "name": "一心堂", "medNum": "20", "docNum": "10", "illNum": "2", "thingNum": "20" },
      { "code": "06", "name": "怡康大药房", "medNum": "20", "docNum": "10", "illNum": "2", "thingNum": "20" }
    ],
    indicatorDots: true,
    autoplay: true,
    interval: 5000,
    duration: 1000,
    allMed: 120,
    allDoc: 60,
    allIll: 12,
    allBox: 120,
    show: false,//控制下拉列表的显示隐藏，false隐藏、true显示
    initName: "所有药店名称",
    selectData: ['同仁堂', '老百姓', '国大药房', '大参林', '一心堂', '怡康大药房'],//下拉列表的数据
    index: 0//选择的下拉列表下标
  },
  //点击下拉显示框
  selectTap() {
    this.setData({
      show: !this.data.show
    });
  },
  // 点击下拉列表
  optionTap(e) {
    // 获取对应项对应的药店名称
    let Index = e.currentTarget.dataset.index;//获取点击的下拉列表的下标
    this.setData({
      initName: this.data.selectData[Index],
      show: !this.data.show
    });
  },
  // 滚动切换标签样式
  switchTab: function (e) {
    this.setData({
      currentTab: e.detail.current
    });
    this.checkCor();
  },
  // 点击标题切换当前页时改变样式
  swichNav: function (e) {
    var cur = e.target.dataset.current;
    if (this.data.currentTaB == cur) { return false; }
    else {
      this.setData({
        currentTab: cur
      })
    }
  },
  //判断当前滚动超过一屏时，设置tab标题滚动条。
  checkCor: function () {
    if (this.data.currentTab > 4) {
      this.setData({
        scrollLeft: 300
      })
    } else {
      this.setData({
        scrollLeft: 0
      })
    }
  },
  onLoad: function () {
    var that = this;
    // 调用函数时，传入new Date()参数，返回值是日期和时间
    var time = util.formatTime(new Date());
    this.setData({
      time: time
    });
    //  高度自适应
    wx.getSystemInfo({
      success: function (res) {
        var clientHeight = res.windowHeight,
          clientWidth = res.windowWidth,
          rpxR = 750 / clientWidth;
        var calc = clientHeight * rpxR - 180;
        console.log(calc)
        that.setData({
          winHeight: calc
        });
      } 
    });
    
    // 再通过setData更改Page()里面的data，动态更新页面的数据
    },
  footerTap: app.footerTap
})









